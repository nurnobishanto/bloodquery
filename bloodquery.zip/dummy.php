<?php

// require_once("connect.php");
// for($i=1;$i<500;$i++)
// {
//     $email="md".$i."@dummy.com";
//     $phone="017706348".$i;
//  $insertSQL="INSERT INTO blood_req_post (title,bunit,pname,page,purpose,bgroup,email,phone,wnb,gender,hname,addr,city,zip,detail,puid) VALUES
//  ('Title-Dummy','$i','Dummy Name','10','Purpose','A+','$email','$phone','200','Male','Hospital Name','Dhaka','Jamalpur','2012','N/A','10')";
// mysqli_query($connect,$insertSQL);
// }


?>