<?php 

require_once ("header.php");

?>

      <div id="content-wrapper">

        <div class="container-fluid">

          <!-- Breadcrumbs-->
          <ol class="breadcrumb">
            <li class="breadcrumb-item">
              <a href="index.php">Dashboard</a>
            </li>
            <li class="breadcrumb-item active">customize</li>
          </ol>

          <!-- Page Content -->
          <h2>Website Customize Area</h2>
          <hr>
          <p>This is a great starting point for new custom pages.</p>

        </div>
        <!-- /.container-fluid -->

        <?php 

require_once ("footer.php");

?>