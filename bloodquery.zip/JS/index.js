function goRegistraionPage(){
    window.location.href="../registration.html";
}

function goLoginPage(){
    window.location.href="../bloodquery/login.php";
}
function gotoreset()
{
    window.location.href="../reset-password.html";
}
function openNav() {
    document.getElementById("mySidenav").style.width = "250px";
    document.getElementById("mySidenav").style.marginTop = "59px";
    document.getElementById("main").style.display = "block";
  }
  
  function closeNav() {
    document.getElementById("mySidenav").style.width = "0";
    document.getElementById("main").style.display= "block";
  }


