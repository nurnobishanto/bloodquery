<?php
$q = intval($_GET['q']);

// $con = mysqli_connect('localhost','peter','abc123','my_db');
// if (!$con) {
//   die('Could not connect: ' . mysqli_error($con));
// }

// mysqli_select_db($con,"ajax_demo");
// $sql="SELECT * FROM user WHERE id = '".$q."'";
// $result = mysqli_query($con,$sql);

// echo "<table>
// <tr>
// <th>Firstname</th>
// <th>Lastname</th>
// <th>Age</th>
// <th>Hometown</th>
// <th>Job</th>
// </tr>";
// while($row = mysqli_fetch_array($result)) {
//   echo "<tr>";
//   echo "<td>" . $row['FirstName'] . "</td>";
//   echo "<td>" . $row['LastName'] . "</td>";
//   echo "<td>" . $row['Age'] . "</td>";
//   echo "<td>" . $row['Hometown'] . "</td>";
//   echo "<td>" . $row['Job'] . "</td>";
//   echo "</tr>";
// }
// echo "</table>";
// mysqli_close($con);
echo "hello";
?>

<!-- <div class="row ">
                
                <div class="col-lg-3 col-md-4 col-sm-6">
                  <div class="mr-1 blood-request-card p-1 mb-3">
                    <div class="imgcontainer">
                      <img src="IMG/avatar.png" alt="Avatar" class="avatar">
                    </div>
                    <h5 class="text-center text-danger">Emergency blood needed </h5>
                    <p class="text-center text-secondary">Post Date: October 11, 2018</p>

                    <ul class="list-group">
                      <li class="list-group-item">Blood Group : AB+</li>
                      <li class="list-group-item">Unit/Bag (S): 5</li>
                      <li class="list-group-item"> October 11, 2018</li>
                      <li class="list-group-item">01770634816</li>
                    </ul>
                    <a href="#"> <button class="bg-info">See Deatils </button></a>
                   
                  </div>
                </div>

                <div class="col-lg-3 col-md-4 col-sm-6">
                  <div class="mr-1 blood-request-card p-1">
                    <div class="imgcontainer">
                      <img src="IMG/avatar.png" alt="Avatar" class="avatar">
                    </div>
                    <h5 class="text-center text-danger">Emergency blood needed </h5>
                    <p class="text-center text-secondary">Post Date: October 11, 2018</p>

                    <ul class="list-group">
                      <li class="list-group-item">Blood Group : AB+</li>
                      <li class="list-group-item">Unit/Bag (S): 5</li>
                      <li class="list-group-item"> October 11, 2018</li>
                      <li class="list-group-item">01770634816</li>
                    </ul>
                    <a href="#"> <button class="bg-info">See Deatils </button></a>
                   
                  </div>
                </div>

                <div class="col-lg-3 col-md-4 col-sm-6">
                  <div class="mr-1 blood-request-card p-1">
                    <div class="imgcontainer">
                      <img src="IMG/avatar.png" alt="Avatar" class="avatar">
                    </div>
                    <h5 class="text-center text-danger">Emergency blood needed </h5>
                    <p class="text-center text-secondary">Post Date: October 11, 2018</p>

                    <ul class="list-group">
                      <li class="list-group-item">Blood Group : AB+</li>
                      <li class="list-group-item">Unit/Bag (S): 5</li>
                      <li class="list-group-item"> October 11, 2018</li>
                      <li class="list-group-item">01770634816</li>
                    </ul>
                    <a href="#"> <button class="bg-info">See Deatils </button></a>
                   
                  </div>
                </div>

                <div class="col-lg-3 col-md-4 col-sm-6">
                  <div class="mr-1 blood-request-card p-1">
                    <div class="imgcontainer">
                      <img src="IMG/avatar.png" alt="Avatar" class="avatar">
                    </div>
                    <h5 class="text-center text-danger">Emergency blood needed </h5>
                    <p class="text-center text-secondary">Post Date: October 11, 2018</p>

                    <ul class="list-group">
                      <li class="list-group-item">Blood Group : AB+</li>
                      <li class="list-group-item">Unit/Bag (S): 5</li>
                      <li class="list-group-item"> October 11, 2018</li>
                      <li class="list-group-item">01770634816</li>
                    </ul>
                    <a href="#"> <button class="bg-info">See Deatils </button></a>
                   
                  </div>
                </div>
 
              </div>
          
     -->